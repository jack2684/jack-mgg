	var wordSpaces;
	var wordArray;
	var a = "";
	var p;
	var i=0;
	var activeLine=0;
	var stage;
	var level=0;

function scrollIn() {
	console.log("scrollIn");
	p=wordSpaces[activeLine];
	i++;
	if(i > wordArray[activeLine].length) {
		wordSpaces[activeLine].innerHTML = a;
		activeLine++;
		i=0;
		
		if(activeLine >= wordArray.length){
			//scroll is finished
			createjs.Ticker.setFPS(24);
			createjs.Ticker.addListener(stage);
			return;
			}
		setTimeout("scrollIn()",25);
		return;
	 }
	a = wordArray[activeLine].substring(0,i);
	if(a=="!"){
		i=0;
		setTimeout("scrollIn()",25);
		p.style.backgroundColor = "black";
		activeLine++;
		return;
	}
	p.innerHTML = a+"_";
	setTimeout("scrollIn()",25);
}

window.onload = function(){
		//set up array with user's words here
		
	//passed levels should be added as "!"
	wordArray=["Word", "Words", "wordss", "Word", "Words", "wordss", "Word", "Words", "wordss", "Word"];
	
	//determine level by length of word array, minus passes
	for(var i=0; i<wordArray.length; i++){
		if(wordArray[i] != "!"){
			level++;
		}
	}
	//set up text message
	var message=document.getElementById("gameMessage");
	var messageString;
	switch(level){
		case 0:
		messageString="STUPID ROBOT IS STILL COMPLETELY STUPID!";
		break;
		case 1:
		messageString="STUPID ROBOT AN ITTY BITTY BIT SMARTER.";
		break;
		case 2:
		messageString="STUPID ROBOT A TINY BIT SMARTER.";
		break;
		case 3:
		messageString="STUPID ROBOT SLIGHTLY SMARTER.";
		break;
		default:
		messageString="STUPID ROBOT AN ITTY BITTY BIT SMARTER.";
	}
	
	message.innerHTML="YOU TAUGHT STUPID ROBOT "+level+" WORDS!<br>"+messageString;
	
	console.log("level: ", level);

	var canvas = document.getElementById("canvas");
	var exportRoot = new lib.animation_score(level);

	stage = new createjs.Stage(canvas);
	stage.addChild(exportRoot);
	stage.update();

	//set up scroller
	var wordspaceCollection=document.getElementsByClassName("underlinedText");
	wordSpaces = Array.prototype.slice.call( wordspaceCollection );
	scrollIn();
};
